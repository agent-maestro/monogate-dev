`timescale 1ns / 1ps

// Synchronizes a raw push-button to the system clock, debounces it, and exposes
// both a clean level (for momentary "hold" inputs like the surge button) and a
// one-cycle rising-edge pulse (for "press once" inputs like limit +/- and clear).
//
// The Arty A7 push buttons read high while pressed, low at rest.
module button_conditioner #(
    parameter integer DEBOUNCE_CYCLES = 1000000 // ~10 ms @ 100 MHz
) (
    input wire clk,
    input wire raw,
    output reg level = 1'b0,  // debounced, held while pressed
    output reg rising = 1'b0  // 1-cycle pulse on a clean press edge
);
    reg sync0 = 1'b0;
    reg sync1 = 1'b0;
    reg prev_level = 1'b0;
    reg [19:0] count = 20'd0;

    always @(posedge clk) begin
        // 2-flop synchronizer for the asynchronous button input
        sync0 <= raw;
        sync1 <= sync0;

        rising <= 1'b0;

        // Debounce: the candidate level must hold steady for DEBOUNCE_CYCLES
        if (sync1 == level) begin
            count <= 20'd0;
        end else begin
            count <= count + 20'd1;
            if (count == DEBOUNCE_CYCLES - 1) begin
                level <= sync1;
                count <= 20'd0;
            end
        end

        // Rising-edge detect on the debounced level
        prev_level <= level;
        if (level && !prev_level) begin
            rising <= 1'b1;
        end
    end
endmodule
