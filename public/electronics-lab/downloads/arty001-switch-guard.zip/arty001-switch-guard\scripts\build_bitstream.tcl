# Build the ARTY-001 switch guard bitstream.
# This script does not open hardware manager and does not program the board.

set script_dir [file dirname [file normalize [info script]]]
set root_dir [file normalize [file join $script_dir ".."]]
set project_dir [file join $root_dir "build" "vivado" "arty001_switch_guard"]
set output_dir [file join $root_dir "build" "bitstream"]

file mkdir $output_dir

create_project arty001_switch_guard $project_dir -part xc7a100tcsg324-1 -force
set_property target_language Verilog [current_project]

add_files [file join $root_dir "rtl" "arty001_switch_guard_top.v"]
add_files [file join $root_dir "rtl" "reflex_kernel.v"]
add_files [file join $root_dir "rtl" "guard_clamp.v"]
add_files [file join $root_dir "rtl" "button_conditioner.v"]
add_files [file join $root_dir "rtl" "uart_json_tx.v"]
add_files -fileset constrs_1 [file join $root_dir "constraints" "arty001_switch_guard.xdc"]

set_property top arty001_switch_guard_top [current_fileset]
update_compile_order -fileset sources_1

launch_runs synth_1 -jobs 4
wait_on_run synth_1
if {[get_property PROGRESS [get_runs synth_1]] != "100%"} {
  error "synth_1 did not complete"
}
if {[get_property STATUS [get_runs synth_1]] != "synth_design Complete!"} {
  error "synth_1 status: [get_property STATUS [get_runs synth_1]]"
}

launch_runs impl_1 -to_step write_bitstream -jobs 4
wait_on_run impl_1
if {[get_property PROGRESS [get_runs impl_1]] != "100%"} {
  error "impl_1 did not complete"
}
if {[string first "write_bitstream Complete!" [get_property STATUS [get_runs impl_1]]] < 0} {
  error "impl_1 status: [get_property STATUS [get_runs impl_1]]"
}

open_run impl_1
report_timing_summary -file [file join $output_dir "timing_summary.rpt"]
report_utilization -file [file join $output_dir "utilization.rpt"]
report_drc -file [file join $output_dir "drc.rpt"]

set run_bit [file join $project_dir "arty001_switch_guard.runs" "impl_1" "arty001_switch_guard_top.bit"]
set out_bit [file join $output_dir "arty001_switch_guard_top.bit"]
if {![file exists $run_bit]} {
  error "bitstream not found: $run_bit"
}
file copy -force $run_bit $out_bit

puts "Generated ARTY-001 bitstream: $out_bit"
puts "Hardware programming was not performed."
