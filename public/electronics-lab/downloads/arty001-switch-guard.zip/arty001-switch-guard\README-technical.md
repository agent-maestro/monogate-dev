# ARTY-001 Switch Guard FPGA Starter

This is the course-owned FPGA starter design for ARTY-001.

It mirrors the browser simulator's "guard you can feel" so the same contract
runs on real hardware:

- `SW3..SW0` set the requested demand (0-15).
- `BTN0` adds a momentary surge to the demand while held (level input).
- `BTN1` / `BTN2` raise / lower the safe limit, one Q8 step (~0.05) per press.
  Holding `BTN1`+`BTN2` together snaps the limit back to the `0.60` default (so a
  limit walked into a rail can always be recovered).
- `BTN3` clears a latched violation (it re-latches if the request is still over
  the limit).
- The guard clamps the requested output to the current safe limit (default
  `153` Q8 = `0.60`, the same value the ESP32 reflex course enforced).
- `LD4-LD7` (the four discrete user LEDs) show the safe-output bar.
- RGB `LD0`: green = guard passing, red = guard clamping.
- RGB `LD1`: amber while a violation is latched (`BTN3` clears it).
- The FPGA transmits compact JSONL frames over the Arty USB UART at `115200`
  baud, carrying the `monogate-electronics.arty-trace-frame.v0` contract:
  `switch_bits`, `button_pressed`, `requested_output_q8`, `safe_output_q8`,
  `safety_margin_q8`, `safe_limit_q8`, and `violation_latched`. The local
  dashboard renders these directly.

Buttons are debounced and edge-detected in `button_conditioner.v` so each press
registers once.

This folder is the Arty A7 equivalent of a firmware sketch for this course.
Local builds write the generated bitstream and reports under `build/`; those
generated files are still release-gated before any public student packet.

## Files

```text
rtl/arty001_switch_guard_top.v
rtl/reflex_kernel.v
rtl/guard_clamp.v
rtl/button_conditioner.v
rtl/uart_json_tx.v
constraints/arty001_switch_guard.xdc
validation/sim/tb_reflex_kernel.v
validation/sim/tb_guard_clamp.v
validation/sim/run_all_and_quit.tcl
scripts/build_bitstream.tcl
scripts/check_hardware.tcl
scripts/program_volatile_fpga.tcl
```

## Course Boundary

This package is local-course ready, but the public student packet is still
release-gated:

- HDL simulation
- Vivado synthesis/implementation
- timing and DRC review
- explicit programming approval
- physical Arty A7 smoke test
- documented evidence capture
- student packet packaging

Do not treat this folder as a public download until those steps are complete.

## Build

From the repository root, with Vivado available:

```powershell
& D:\vivado\2025.2.1\Vivado\bin\vivado.bat -mode batch -source courses\008-arty-a7-reflex-logic\resources\arty001-switch-guard\scripts\build_bitstream.tcl
```

The generated bitstream, reports, and temporary Vivado project are written under:

```text
resources/arty001-switch-guard/build/
```

## Hardware Check

This only checks that Vivado can see an attached `xc7a100t` target:

```powershell
& D:\vivado\2025.2.1\Vivado\bin\vivado.bat -mode batch -source courses\008-arty-a7-reflex-logic\resources\arty001-switch-guard\scripts\check_hardware.tcl
```

## Expected Physical Behavior

- `LD4-LD7` are the four discrete user LEDs driven by the safe-output bar.
- `LD0` (RGB): green = guard passing, red = guard clamping.
- `LD1` (RGB): amber while a violation is latched.
- `BTN0` held = surge: it pushes the request up and can clamp the safe bar at
  the limit while `LD0` turns red and `LD1` latches.
- `BTN1` / `BTN2` raise / lower the safe limit (watch the clamp point move). Hold
  both together to reset the limit to the `0.60` default.
- `BTN3` clears the latched violation (`LD1` off), re-latching if still clamped.
- The local dashboard should auto-detect the Arty USB serial port and begin
  receiving frames once this bitstream is programmed. The graph's dashed
  safe-limit line tracks `safe_limit_q8`, so it moves when you press
  `BTN1`/`BTN2`.

## Dashboard Setup Notes

Run the dashboard from the repository root:

```powershell
python dashboard\artya7-fpga\dashboard.py --open-browser
```

Expected local URL:

```text
http://127.0.0.1:5192/
```

If auto-detect needs help:

```powershell
python dashboard\artya7-fpga\dashboard.py --port COM5 --baud 115200
```

If the dashboard says `Access is denied`, the COM port is already open in
another app. Close the other serial monitor/dashboard and restart this one.

If the dashboard connects but shows no frames, reprogram the volatile bitstream.
The Arty loses volatile FPGA programming after power is removed.

## Volatile Programming

Run only after approval:

```powershell
& D:\vivado\2025.2.1\Vivado\bin\vivado.bat -mode batch -source courses\008-arty-a7-reflex-logic\resources\arty001-switch-guard\scripts\program_volatile_fpga.tcl
```
