@echo off
title ARTY-001 Switch Guard dashboard
rem ============================================================
rem  Starts the Arty live serial dashboard for ARTY-001.
rem  Program the bitstream first if the board is blank:
rem    vivado -mode batch -source scripts\program_volatile_fpga.tcl
rem  Needs Python 3 with pyserial (pip install pyserial).
rem ============================================================
cd /d "%~dp0dashboard"
echo Starting the Arty dashboard at http://127.0.0.1:5192/ ...
echo If the board is on a specific COM port, add  --port COM5  to the line below.
python dashboard.py --open-browser
pause
