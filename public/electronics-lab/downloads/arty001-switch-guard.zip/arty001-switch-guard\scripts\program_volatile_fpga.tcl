# Program the ARTY-001 bitstream into volatile FPGA fabric only.
# This does not write QSPI/configuration flash and does not persist after power
# cycle. Use only after explicit bench approval.

set script_dir [file dirname [file normalize [info script]]]
set root_dir [file normalize [file join $script_dir ".."]]
set bitstream [file join $root_dir "build" "bitstream" "arty001_switch_guard_top.bit"]

if {![file exists $bitstream]} {
  error "bitstream not found: $bitstream"
}

open_hw_manager
connect_hw_server

set targets [get_hw_targets]
puts "Hardware targets:"
foreach target $targets {
  puts "  $target"
}
if {[llength $targets] == 0} {
  error "no hardware targets found"
}

open_hw_target [lindex $targets 0]

set devices [get_hw_devices *xc7a100t*]
if {[llength $devices] == 0} {
  puts "Available hardware devices:"
  foreach dev [get_hw_devices] {
    puts "  $dev PART=[get_property PART $dev]"
  }
  error "no xc7a100t hardware device found"
}
if {[llength $devices] > 1} {
  puts "Matched devices:"
  foreach dev $devices {
    puts "  $dev PART=[get_property PART $dev]"
  }
  error "multiple xc7a100t devices found; program manually"
}

set dev [lindex $devices 0]
current_hw_device $dev
refresh_hw_device $dev
set_property PROGRAM.FILE $bitstream $dev
program_hw_devices $dev
refresh_hw_device $dev

puts "Programmed volatile FPGA fabric: $dev"
puts "Bitstream: $bitstream"
puts "QSPI/configuration flash was not written."
