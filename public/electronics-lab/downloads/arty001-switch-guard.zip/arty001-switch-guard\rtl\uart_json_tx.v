`timescale 1ns / 1ps

module uart_json_tx #(
    parameter integer CLK_HZ = 100000000,
    parameter integer BAUD = 115200,
    parameter integer FRAME_PERIOD_CYCLES = 10000000
) (
    input wire clk,
    input wire [3:0] switch_value,
    input wire button_pressed,
    input wire [7:0] requested_output_q8,
    input wire [7:0] safe_output_q8,
    input wire [7:0] safety_margin_q8,
    input wire [7:0] safe_limit_q8,
    input wire violation_latched,
    output wire tx
);
    localparam integer FRAME_LEN = 381;
    localparam [FRAME_LEN * 8 - 1:0] FRAME_TEMPLATE =
        "{\"schema_version\":\"monogate-electronics.arty-trace-frame.v0\",\"kernel_id\":\"arty001_switch_guard_v0\",\"source\":\"arty-a7\",\"mode\":\"switch_guard\",\"sample_index\":\"0xSSSSSSSS\",\"timestamp_ms\":\"0xTTTTTTTT\",\"switch_bits\":\"BBBB\",\"button_pressed\":\"P\",\"requested_output_q8\":\"0xRR\",\"safe_output_q8\":\"0xAA\",\"led_q8\":\"0xLL\",\"safety_margin_q8\":\"0xMM\",\"safe_limit_q8\":\"0xKK\",\"violation_latched\":\"V\"}\n";

    localparam integer SAMPLE_POS = 158;
    localparam integer TIME_POS = 186;
    localparam integer SWITCH_POS = 211;
    localparam integer BUTTON_POS = 235;
    localparam integer REQUEST_POS = 263;
    localparam integer SAFE_POS = 287;
    localparam integer LED_POS = 303;
    localparam integer MARGIN_POS = 329;
    localparam integer LIMIT_POS = 352;
    localparam integer VIOLATION_POS = 377;

    reg [31:0] period_counter = 32'd0;
    reg [31:0] sample_counter = 32'd0;
    reg [31:0] sample_index_snapshot = 32'd0;
    reg [31:0] timestamp_ms_snapshot = 32'd0;
    reg [3:0] switch_snapshot = 4'd0;
    reg button_snapshot = 1'b0;
    reg [7:0] request_snapshot = 8'd0;
    reg [7:0] safe_snapshot = 8'd0;
    reg [7:0] margin_snapshot = 8'd0;
    reg [7:0] limit_snapshot = 8'd0;
    reg violation_snapshot = 1'b0;

    reg sending = 1'b0;
    reg [8:0] frame_pos = 9'd0;
    reg tx_start = 1'b0;
    reg [7:0] tx_data = 8'h00;
    wire tx_busy;

    uart_tx_byte #(
        .CLK_HZ(CLK_HZ),
        .BAUD(BAUD)
    ) uart (
        .clk(clk),
        .start(tx_start),
        .data(tx_data),
        .tx(tx),
        .busy(tx_busy)
    );

    function [7:0] hex_char;
        input [3:0] nibble;
        begin
            hex_char = nibble < 4'd10 ? 8'd48 + nibble : 8'd65 + (nibble - 4'd10);
        end
    endfunction

    function [7:0] word_hex_digit;
        input [31:0] value;
        input integer digit_index;
        begin
            case (digit_index)
                0: word_hex_digit = hex_char(value[31:28]);
                1: word_hex_digit = hex_char(value[27:24]);
                2: word_hex_digit = hex_char(value[23:20]);
                3: word_hex_digit = hex_char(value[19:16]);
                4: word_hex_digit = hex_char(value[15:12]);
                5: word_hex_digit = hex_char(value[11:8]);
                6: word_hex_digit = hex_char(value[7:4]);
                default: word_hex_digit = hex_char(value[3:0]);
            endcase
        end
    endfunction

    function [7:0] q8_hex_digit;
        input [7:0] value;
        input integer digit_index;
        begin
            case (digit_index)
                0: q8_hex_digit = hex_char(value[7:4]);
                default: q8_hex_digit = hex_char(value[3:0]);
            endcase
        end
    endfunction

    function [7:0] template_byte;
        input [8:0] pos;
        begin
            template_byte = FRAME_TEMPLATE[(FRAME_LEN - 1 - pos) * 8 +: 8];
        end
    endfunction

    function [7:0] frame_byte;
        input [8:0] pos;
        integer relative_pos;
        begin
            frame_byte = template_byte(pos);

            if (pos >= SAMPLE_POS && pos < SAMPLE_POS + 8) begin
                relative_pos = pos - SAMPLE_POS;
                frame_byte = word_hex_digit(sample_index_snapshot, relative_pos);
            end else if (pos >= TIME_POS && pos < TIME_POS + 8) begin
                relative_pos = pos - TIME_POS;
                frame_byte = word_hex_digit(timestamp_ms_snapshot, relative_pos);
            end else if (pos >= SWITCH_POS && pos < SWITCH_POS + 4) begin
                relative_pos = pos - SWITCH_POS;
                frame_byte = switch_snapshot[3 - relative_pos] ? "1" : "0";
            end else if (pos == BUTTON_POS) begin
                frame_byte = button_snapshot ? "1" : "0";
            end else if (pos >= REQUEST_POS && pos < REQUEST_POS + 2) begin
                relative_pos = pos - REQUEST_POS;
                frame_byte = q8_hex_digit(request_snapshot, relative_pos);
            end else if (pos >= SAFE_POS && pos < SAFE_POS + 2) begin
                relative_pos = pos - SAFE_POS;
                frame_byte = q8_hex_digit(safe_snapshot, relative_pos);
            end else if (pos >= LED_POS && pos < LED_POS + 2) begin
                relative_pos = pos - LED_POS;
                frame_byte = q8_hex_digit(safe_snapshot, relative_pos);
            end else if (pos >= MARGIN_POS && pos < MARGIN_POS + 2) begin
                relative_pos = pos - MARGIN_POS;
                frame_byte = q8_hex_digit(margin_snapshot, relative_pos);
            end else if (pos >= LIMIT_POS && pos < LIMIT_POS + 2) begin
                relative_pos = pos - LIMIT_POS;
                frame_byte = q8_hex_digit(limit_snapshot, relative_pos);
            end else if (pos == VIOLATION_POS) begin
                frame_byte = violation_snapshot ? "1" : "0";
            end
        end
    endfunction

    always @(posedge clk) begin
        tx_start <= 1'b0;

        if (period_counter == FRAME_PERIOD_CYCLES - 1) begin
            period_counter <= 32'd0;
            if (!sending) begin
                sample_index_snapshot <= sample_counter;
                timestamp_ms_snapshot <= sample_counter * 32'd100;
                switch_snapshot <= switch_value;
                button_snapshot <= button_pressed;
                request_snapshot <= requested_output_q8;
                safe_snapshot <= safe_output_q8;
                margin_snapshot <= safety_margin_q8;
                limit_snapshot <= safe_limit_q8;
                violation_snapshot <= violation_latched;
                sample_counter <= sample_counter + 32'd1;
                frame_pos <= 9'd0;
                sending <= 1'b1;
            end
        end else begin
            period_counter <= period_counter + 32'd1;
        end

        if (sending && !tx_busy && !tx_start) begin
            tx_data <= frame_byte(frame_pos);
            tx_start <= 1'b1;
            if (frame_pos == FRAME_LEN - 1) begin
                sending <= 1'b0;
                frame_pos <= 9'd0;
            end else begin
                frame_pos <= frame_pos + 9'd1;
            end
        end
    end
endmodule

module uart_tx_byte #(
    parameter integer CLK_HZ = 100000000,
    parameter integer BAUD = 115200
) (
    input wire clk,
    input wire start,
    input wire [7:0] data,
    output reg tx = 1'b1,
    output reg busy = 1'b0
);
    localparam integer CLKS_PER_BIT = CLK_HZ / BAUD;

    reg [15:0] clk_count = 16'd0;
    reg [3:0] bit_index = 4'd0;
    reg [9:0] shift = 10'b1111111111;

    always @(posedge clk) begin
        if (!busy) begin
            tx <= 1'b1;
            clk_count <= 16'd0;
            bit_index <= 4'd0;
            if (start) begin
                shift <= {1'b1, data, 1'b0};
                busy <= 1'b1;
                tx <= 1'b0;
            end
        end else begin
            if (clk_count == CLKS_PER_BIT - 1) begin
                clk_count <= 16'd0;
                bit_index <= bit_index + 4'd1;
                if (bit_index == 4'd9) begin
                    busy <= 1'b0;
                    tx <= 1'b1;
                end else begin
                    tx <= shift[bit_index + 1];
                end
            end else begin
                clk_count <= clk_count + 16'd1;
            end
        end
    end
endmodule
