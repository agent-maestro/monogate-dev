`timescale 1ns / 1ps

// ARTY-001 reflex guard. Mirrors the browser simulator's "guard you can feel":
//   SW3..SW0  -> requested demand (0..15)
//   BTN0      -> momentary surge added to the demand (level, while held)
//   BTN1/BTN2 -> raise / lower the safe limit (one step per press)
//   BTN3      -> clear a latched violation (re-latches if still over the limit)
//   LD4..LD7  -> safe-output bar          (led[3:0])
//   LD0 RGB   -> guard status: green = pass, red = clamp
//   LD1 RGB   -> amber while a violation is latched
//   UART      -> monogate-electronics.arty-trace-frame.v0 contract frame
module arty001_switch_guard_top (
    input wire clk_100mhz,
    input wire [3:0] sw,
    input wire [3:0] btn,
    output reg [3:0] led,
    output reg led0_r,
    output reg led0_g,
    output reg led0_b,
    output reg led1_r,
    output reg led1_g,
    output reg led1_b,
    output wire uart_txd
);
    // Safe-output limit in Q8. Default 153 (= 0.60) is the same clamp the ESP32
    // reflex course enforced -- the bridge: same contract, different substrate.
    localparam [7:0] LIMIT_DEFAULT = 8'd153;
    localparam [7:0] LIMIT_MIN     = 8'd51;   // 0.20
    localparam [7:0] LIMIT_MAX     = 8'd255;  // 1.00
    localparam [7:0] LIMIT_STEP    = 8'd13;   // ~0.05

    // Debounced + edge-detected buttons.
    wire btn0_level, btn1_level, btn2_level, btn1_rise, btn2_rise, btn3_rise, btn3_level;

    button_conditioner b0 (.clk(clk_100mhz), .raw(btn[0]), .level(btn0_level), .rising());
    button_conditioner b1 (.clk(clk_100mhz), .raw(btn[1]), .level(btn1_level), .rising(btn1_rise));
    button_conditioner b2 (.clk(clk_100mhz), .raw(btn[2]), .level(btn2_level), .rising(btn2_rise));
    button_conditioner b3 (.clk(clk_100mhz), .raw(btn[3]), .level(btn3_level), .rising(btn3_rise));

    reg [7:0] limit_q8 = LIMIT_DEFAULT;
    reg violation_latched = 1'b0;
    reg [25:0] blink_counter = 26'd0;  // ~1.5 Hz blink phase for the latched-violation LED

    wire [7:0] requested_output_q8;
    wire [7:0] safe_output_q8;
    wire [7:0] safety_margin_q8;
    wire guard_action;

    reflex_kernel kernel (
        .switch_value(sw),
        .perturb(btn0_level),
        .requested_output_q8(requested_output_q8)
    );

    guard_clamp guard (
        .requested_output_q8(requested_output_q8),
        .max_output_q8(limit_q8),
        .safe_output_q8(safe_output_q8),
        .safety_margin_q8(safety_margin_q8),
        .guard_action(guard_action)
    );

    uart_json_tx telemetry (
        .clk(clk_100mhz),
        .switch_value(sw),
        .button_pressed(btn0_level),
        .requested_output_q8(requested_output_q8),
        .safe_output_q8(safe_output_q8),
        .safety_margin_q8(safety_margin_q8),
        .safe_limit_q8(limit_q8),
        .violation_latched(violation_latched),
        .tx(uart_txd)
    );

    always @(posedge clk_100mhz) begin
        // Hold BTN1+BTN2 together to snap the limit back to the default (0.60) so a
        // student who walks the limit into a rail can always recover it. Otherwise a
        // single press nudges the limit one step, clamped to [MIN, MAX].
        if (btn1_level && btn2_level) begin
            limit_q8 <= LIMIT_DEFAULT;
        end else if (btn1_rise) begin
            limit_q8 <= (limit_q8 > LIMIT_MAX - LIMIT_STEP) ? LIMIT_MAX : limit_q8 + LIMIT_STEP;
        end else if (btn2_rise) begin
            limit_q8 <= (limit_q8 < LIMIT_MIN + LIMIT_STEP) ? LIMIT_MIN : limit_q8 - LIMIT_STEP;
        end

        // Latch a violation when the guard clamps; BTN3 clears it (and it re-latches
        // next cycle if the request is still over the limit). Clear on either the
        // edge OR the held level so a press always lands even if edge-detect is missed.
        if (btn3_rise || btn3_level) begin
            violation_latched <= 1'b0;
        end else if (guard_action) begin
            violation_latched <= 1'b1;
        end

        // Free-running blink phase for the latched-violation LED.
        blink_counter <= blink_counter + 26'd1;

        // Outputs.
        led    <= safe_output_q8[7:4];  // LD4..LD7 safe bar
        led0_r <= guard_action;         // LD0 red while clamping
        led0_g <= ~guard_action;        // LD0 green while passing
        led0_b <= 1'b0;
        // LD1 BLINKS while a violation is latched. The red die is dead on the bench
        // board, so the steady-vs-blinking distinction carries the alert (clearer than
        // a solid light anyway). ~1.5 Hz from bit 25 of the 100 MHz blink counter.
        led1_r <= violation_latched & blink_counter[25];
        led1_g <= violation_latched & blink_counter[25];
        led1_b <= 1'b0;
    end
endmodule
