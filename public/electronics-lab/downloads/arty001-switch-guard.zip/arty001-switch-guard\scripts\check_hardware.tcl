# Check for an attached Arty A7 without programming it.

open_hw_manager
connect_hw_server

set targets [get_hw_targets]
puts "Hardware targets:"
foreach target $targets {
  puts "  $target"
}
if {[llength $targets] == 0} {
  error "no hardware targets found"
}

open_hw_target [lindex $targets 0]

set all_devices [get_hw_devices]
puts "Hardware devices:"
foreach dev $all_devices {
  puts "  $dev PART=[get_property PART $dev]"
}

set arty_devices [get_hw_devices *xc7a100t*]
if {[llength $arty_devices] == 0} {
  error "no xc7a100t hardware device found"
}

puts "Matched Arty A7 device count: [llength $arty_devices]"
