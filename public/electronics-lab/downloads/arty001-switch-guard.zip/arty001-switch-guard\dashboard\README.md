# Arty A7 / FPGA Serial Dashboard

Local live dashboard for ARTY-001 and future Arty A7 FPGA courses.

This dashboard is separate from the ESP32 dashboard. It follows the same local
procedure:

```text
connect board -> dashboard auto-detects USB serial -> live frames appear
-> save JSONL trace -> export replay HTML
```

Default run:

```powershell
python dashboard\artya7-fpga\dashboard.py
```

Open the browser automatically:

```powershell
python dashboard\artya7-fpga\dashboard.py --open-browser
```

Manual port override:

```powershell
python dashboard\artya7-fpga\dashboard.py --port COM5 --baud 115200
```

Local URL:

```text
http://127.0.0.1:5192/
```

## Expected Frame Shape

The dashboard accepts flat fields, compact `*_q8` fields, or nested `outputs` /
`guard` fields.
Recommended ARTY-001 frame shape:

```json
{
  "schema_version": "monogate-electronics.arty-trace-frame.v0",
  "kernel_id": "arty001_switch_guard_v0",
  "source": "arty-a7",
  "mode": "switch_guard",
  "sample_index": 42,
  "timestamp_ms": 840,
  "switch_bits": "1010",
  "button_pressed": false,
  "outputs": {
    "requested_output": 0.79,
    "safe_output": 0.60,
    "led": 0.60
  },
  "guard": {
    "guard_action": "clamp_to_safe_output",
    "safety_margin": 0.0,
    "bottleneck": "led_duty_margin"
  }
}
```

The current ARTY-001 FPGA bitstream emits a compact form like:

```json
{
  "schema_version": "monogate-electronics.arty-trace-frame.v0",
  "kernel_id": "arty001_switch_guard_v0",
  "source": "arty-a7",
  "mode": "switch_guard",
  "sample_index": "0x0000002A",
  "timestamp_ms": "0x00001068",
  "switch_bits": "1010",
  "button_pressed": "0",
  "requested_output_q8": "0xAA",
  "safe_output_q8": "0x99",
  "led_q8": "0x99",
  "safety_margin_q8": "0x00"
}
```

The dashboard normalizes those Q8 values for the graph and metric panels.

## Common Troubleshooting

- `Access is denied`: the serial port is already open in another app. Close the
  other dashboard, Serial Monitor, or terminal, then restart this dashboard.
- Connected but no frames: reprogram the volatile ARTY-001 bitstream. The FPGA
  loses volatile programming after a power cycle.
- Wrong port: use `--port COM5 --baud 115200` or the COM port shown in Windows
  Device Manager.
- LED confusion: RGB `LD0` shows status; discrete `LD4-LD7` show safe output.

## Evidence Boundary

- Live mode displays serial frames from a local board.
- Saved traces are JSONL files under `captures/artya7-fpga`.
- Replay HTML exports embed the captured frames for offline review.
- The dashboard visualizes serial evidence. It does not recompute the FPGA
  design or prove the bitstream.
