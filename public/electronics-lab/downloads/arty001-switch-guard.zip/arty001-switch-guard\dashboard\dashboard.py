from __future__ import annotations

import argparse
import json
import sys
import threading
import time
import webbrowser
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

try:
    import serial  # type: ignore
    from serial.tools import list_ports  # type: ignore
except Exception as exc:  # pragma: no cover - depends on operator machine
    serial = None
    list_ports = None
    serial_import_error = str(exc)
else:
    serial_import_error = ""


if getattr(sys, "frozen", False):
    APP_DIR = Path(sys.executable).resolve().parent
    RESOURCE_DIR = Path(getattr(sys, "_MEIPASS", APP_DIR))
    ROOT = APP_DIR
    DASHBOARD_DIR = RESOURCE_DIR
    CAPTURE_DIR = APP_DIR / "captures" / "artya7-fpga"
    SKELETON_PATH = RESOURCE_DIR / "instructor-replay-skeleton.html"
else:
    ROOT = Path(__file__).resolve().parents[2]
    DASHBOARD_DIR = Path(__file__).resolve().parent
    CAPTURE_DIR = ROOT / "captures" / "artya7-fpga"
    SKELETON_PATH = ROOT / "dashboards" / "shared" / "instructor-replay-skeleton.html"

VISUALIZER_PATH = DASHBOARD_DIR / "visualizer.html"

DEFAULT_SERIAL_PORT = "auto"
DEFAULT_BAUD = 115200
DEFAULT_HTTP_PORT = 5192
HOST = "127.0.0.1"
SCAN_READ_SECONDS = 2.4

LIKELY_ARTY_SERIAL_TERMS = (
    "digilent",
    "arty",
    "xilinx",
    "ftdi",
    "usb serial",
    "usb-serial",
    "uart",
    "jtag",
)

state_lock = threading.Lock()
state: dict[str, object] = {
    "connected": False,
    "port": DEFAULT_SERIAL_PORT,
    "baud": DEFAULT_BAUD,
    "error": "",
    "scanning": False,
    "detected_port": None,
    "detected_label": "",
    "available_ports": [],
    "latest": None,
    "frames": 0,
    "started_at": time.time(),
    "updated_at": None,
    "history": [],
    "capture_buffer": [],
    "capture_active": False,
    "capture_frames": 0,
    "last_capture": None,
}


def normalized_number(value: object) -> float | None:
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        clean = value.strip().lower()
        if clean.startswith("0x"):
            try:
                return float(int(clean, 16))
            except Exception:
                return None
    try:
        return float(value)  # type: ignore[arg-type]
    except Exception:
        return None


def clamp01(value: float | None) -> float:
    if value is None:
        return 0.0
    return max(0.0, min(1.0, value))


def normalized_q8(value: object) -> float | None:
    number = normalized_number(value)
    if number is None:
        return None
    return number / 255.0


def normalized_int(value: object) -> int | None:
    number = normalized_number(value)
    if number is None:
        return None
    return int(number)


def normalized_bool(value: object) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value != 0
    if isinstance(value, str):
        return value.strip().lower() in {"1", "true", "yes", "pressed", "down"}
    return False


def normalize_switch_bits(value: object) -> str:
    if isinstance(value, str):
        clean = "".join(ch for ch in value if ch in "01")
        if clean:
            return clean[-4:].zfill(4)
    if isinstance(value, int):
        return format(max(0, min(15, value)), "04b")
    return "0000"


def normalize_frame(frame: dict[str, object], *, source_mode: str = "live_board") -> dict[str, object]:
    raw_frame = frame.get("raw") if isinstance(frame.get("raw"), dict) else frame
    outputs = frame.get("outputs") if isinstance(frame.get("outputs"), dict) else {}
    guard = frame.get("guard") if isinstance(frame.get("guard"), dict) else {}
    latency = frame.get("latency") if isinstance(frame.get("latency"), dict) else {}
    inputs = frame.get("inputs") if isinstance(frame.get("inputs"), dict) else {}

    switch_bits = normalize_switch_bits(frame.get("switch_bits", inputs.get("switch_bits", frame.get("switch_value"))))
    switch_value = int(switch_bits, 2)
    switch_unit = switch_value / 15.0

    requested = outputs.get("requested_output", guard.get("requested_output", frame.get("requested_output")))
    safe = outputs.get("safe_output", guard.get("safe_output", frame.get("safe_output")))
    requested_q8 = outputs.get("requested_output_q8", guard.get("requested_output_q8", frame.get("requested_output_q8")))
    safe_q8 = outputs.get("safe_output_q8", guard.get("safe_output_q8", frame.get("safe_output_q8")))
    requested_number = normalized_number(requested)
    safe_number = normalized_number(safe)

    if requested_number is None:
        requested_number = normalized_q8(requested_q8)
    if safe_number is None:
        safe_number = normalized_q8(safe_q8)

    if requested_number is None:
        requested_number = switch_unit
    if safe_number is None:
        safe_number = min(requested_number, 0.60)

    led_value = normalized_number(outputs.get("led", frame.get("led")))
    if led_value is None:
        led_value = normalized_q8(outputs.get("led_q8", frame.get("led_q8")))
    if led_value is None:
        led_value = safe_number

    button_pressed = frame.get("button_pressed", inputs.get("button_pressed"))
    button_pressed = normalized_bool(button_pressed)

    guard_action = guard.get("guard_action", frame.get("guard_action"))
    if not isinstance(guard_action, str):
        guard_action = "clamp_to_safe_output" if requested_number > safe_number + 0.0001 else "pass_through"

    safety_margin = normalized_number(guard.get("safety_margin", frame.get("safety_margin")))
    if safety_margin is None:
        safety_margin = normalized_q8(guard.get("safety_margin_q8", frame.get("safety_margin_q8")))
    if safety_margin is None:
        safety_margin = max(0.0, safe_number - requested_number) if guard_action == "pass_through" else 0.0

    safe_limit = normalized_number(guard.get("safe_limit", frame.get("safe_limit")))
    if safe_limit is None:
        safe_limit = normalized_q8(guard.get("safe_limit_q8", frame.get("safe_limit_q8")))
    if safe_limit is None:
        safe_limit = 0.60

    violation_latched = normalized_bool(frame.get("violation_latched", guard.get("violation_latched")))

    now = time.time()
    received_at = frame.get("dashboard_received_at")
    received_local = frame.get("dashboard_received_local")
    received_epoch = frame.get("dashboard_received_epoch_ms")

    return {
        "schema_version": frame.get("schema_version") or "monogate-electronics.arty-trace-frame.v0",
        "kernel_id": frame.get("kernel_id") or frame.get("kernel_sha256") or "arty001_switch_guard_v0",
        "source": frame.get("source") or "arty-a7",
        "board_id": frame.get("board_id") or frame.get("fpga_id") or "arty-a7",
        "source_mode": source_mode,
        "mode": frame.get("mode") or "switch_guard",
        "sample_index": normalized_int(frame.get("sample_index")),
        "timestamp_ms": normalized_int(frame.get("timestamp_ms")),
        "dashboard_received_at": received_at if isinstance(received_at, str) else datetime.fromtimestamp(now, timezone.utc).isoformat(timespec="milliseconds"),
        "dashboard_received_local": received_local if isinstance(received_local, str) else datetime.fromtimestamp(now).astimezone().isoformat(timespec="milliseconds"),
        "dashboard_received_epoch_ms": received_epoch if isinstance(received_epoch, int) else int(now * 1000),
        "switch_bits": switch_bits,
        "switch_value": switch_value,
        "pot_raw": switch_unit,
        "requested_output": clamp01(requested_number),
        "safe_output": clamp01(safe_number),
        "led": clamp01(led_value),
        "button_pressed": button_pressed,
        "guard_action": guard_action,
        "safety_margin": clamp01(safety_margin),
        "safe_limit": clamp01(safe_limit),
        "violation_latched": violation_latched,
        "bottleneck": guard.get("bottleneck", frame.get("bottleneck")) or "none",
        "latency": latency,
        "hardware_observed": source_mode == "live_board",
        "dashboard_projection_only": True,
        "raw": raw_frame,
    }


def frame_to_jsonl(frame: dict[str, object]) -> str:
    return json.dumps(frame, separators=(",", ":"))


def compact_frame(frame: dict[str, object]) -> dict[str, object]:
    keys = [
        "schema_version",
        "kernel_id",
        "source",
        "board_id",
        "source_mode",
        "mode",
        "sample_index",
        "timestamp_ms",
        "dashboard_received_at",
        "dashboard_received_local",
        "dashboard_received_epoch_ms",
        "switch_bits",
        "switch_value",
        "pot_raw",
        "requested_output",
        "safe_output",
        "led",
        "button_pressed",
        "guard_action",
        "safety_margin",
        "safe_limit",
        "violation_latched",
        "bottleneck",
        "hardware_observed",
        "dashboard_projection_only",
    ]
    return {key: frame.get(key) for key in keys}


def load_jsonl(path: Path, *, source_mode: str) -> list[dict[str, object]]:
    if not path.exists():
        return []
    frames: list[dict[str, object]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line.startswith("{"):
            continue
        try:
            parsed = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(parsed, dict):
            frames.append(normalize_frame(parsed, source_mode=source_mode))
    return frames


def capture_path(suffix: str = "jsonl") -> Path:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    return CAPTURE_DIR / f"arty001_switch_guard_{stamp}.{suffix}"


def write_capture(frames: list[dict[str, object]]) -> Path:
    CAPTURE_DIR.mkdir(parents=True, exist_ok=True)
    path = capture_path("jsonl")
    path.write_text("\n".join(frame_to_jsonl(frame) for frame in frames) + "\n", encoding="utf-8")
    return path


def latest_capture_path() -> Path | None:
    if not CAPTURE_DIR.exists():
        return None
    files = sorted(CAPTURE_DIR.glob("*.jsonl"), key=lambda path: path.stat().st_mtime, reverse=True)
    return files[0] if files else None


def port_info(port: object) -> dict[str, object]:
    device = str(getattr(port, "device", ""))
    description = str(getattr(port, "description", "") or "")
    manufacturer = str(getattr(port, "manufacturer", "") or "")
    hwid = str(getattr(port, "hwid", "") or "")
    text = " ".join([device, description, manufacturer, hwid]).lower()
    likely = any(term in text for term in LIKELY_ARTY_SERIAL_TERMS)
    label_parts = [device]
    if description and description != device:
        label_parts.append(description)
    if manufacturer and manufacturer not in description:
        label_parts.append(manufacturer)
    return {
        "device": device,
        "description": description,
        "manufacturer": manufacturer,
        "hwid": hwid,
        "label": " - ".join(part for part in label_parts if part),
        "likely_arty": likely,
    }


def list_serial_ports() -> list[dict[str, object]]:
    if list_ports is None:
        return []
    ports = [port_info(port) for port in list_ports.comports()]
    return sorted(ports, key=lambda item: (0 if item.get("likely_arty") else 1, str(item.get("device", ""))))


def is_arty_frame(parsed: object) -> bool:
    if not isinstance(parsed, dict):
        return False
    kernel_id = str(parsed.get("kernel_id") or parsed.get("kernel_sha256") or "").lower()
    source = str(parsed.get("source") or "").lower()
    return (
        "arty" in kernel_id
        or "switch_guard" in kernel_id
        or "fpga" in source
        or "arty" in source
        or "switch_bits" in parsed
        or "switch_value" in parsed
    )


def read_candidate_frame(device: str, baud: int, timeout_seconds: float) -> dict[str, object] | None:
    if serial is None:
        return None
    deadline = time.time() + timeout_seconds
    try:
        with serial.Serial(device, baud, timeout=0.25) as candidate:
            while time.time() < deadline:
                line = candidate.readline().decode("utf-8", errors="ignore").strip()
                safe_line = line.encode("ascii", errors="ignore").decode("ascii")
                if not safe_line.startswith("{"):
                    continue
                try:
                    parsed = json.loads(safe_line)
                except json.JSONDecodeError:
                    continue
                if is_arty_frame(parsed):
                    return parsed
    except Exception:
        return None
    return None


def detect_serial_port(baud: int) -> dict[str, object] | None:
    ports = list_serial_ports()
    with state_lock:
        state["available_ports"] = ports

    for info in ports:
        device = str(info.get("device", ""))
        if not device:
            continue
        parsed = read_candidate_frame(device, baud, SCAN_READ_SECONDS)
        if parsed is not None:
            return {**info, "confirmed_monogate_frame": True}

    likely_ports = [info for info in ports if info.get("likely_arty")]
    if len(likely_ports) == 1:
        return {**likely_ports[0], "confirmed_monogate_frame": False}
    if len(ports) == 1:
        return {**ports[0], "confirmed_monogate_frame": False}
    return None


def serial_reader(port: str, baud: int) -> None:
    if serial is None:
        with state_lock:
            state["error"] = f"pyserial unavailable: {serial_import_error}"
        return

    while True:
        active_port = port
        detected_label = ""
        if port.lower() == "auto":
            with state_lock:
                state.update({
                    "connected": False,
                    "scanning": True,
                    "error": "Scanning for Arty A7 USB serial. Connect the board and wait a few seconds.",
                })
            detected = detect_serial_port(baud)
            with state_lock:
                state["scanning"] = False
            if detected is None:
                with state_lock:
                    state.update({
                        "connected": False,
                        "detected_port": None,
                        "detected_label": "",
                        "error": "No Arty serial stream found yet. Connect the board, then click Scan Again.",
                    })
                time.sleep(2.0)
                continue
            active_port = str(detected.get("device", ""))
            detected_label = str(detected.get("label", active_port))

        try:
            with serial.Serial(active_port, baud, timeout=0.5) as device:
                with state_lock:
                    state.update({
                        "connected": True,
                        "port": active_port,
                        "baud": baud,
                        "error": "",
                        "detected_port": active_port,
                        "detected_label": detected_label or active_port,
                    })

                while True:
                    line = device.readline().decode("utf-8", errors="ignore").strip()
                    safe_line = line.encode("ascii", errors="ignore").decode("ascii")
                    if not safe_line.startswith("{"):
                        continue
                    try:
                        parsed = json.loads(safe_line)
                    except json.JSONDecodeError:
                        continue
                    if not isinstance(parsed, dict):
                        continue
                    if not is_arty_frame(parsed):
                        continue

                    frame = normalize_frame(parsed, source_mode="live_board")
                    now = time.time()
                    frame["dashboard_received_at"] = datetime.fromtimestamp(now, timezone.utc).isoformat(timespec="milliseconds")
                    frame["dashboard_received_local"] = datetime.fromtimestamp(now).astimezone().isoformat(timespec="milliseconds")
                    frame["dashboard_received_epoch_ms"] = int(now * 1000)
                    with state_lock:
                        state["latest"] = frame
                        state["frames"] = int(state["frames"]) + 1
                        state["updated_at"] = now
                        history = state["history"]
                        assert isinstance(history, list)
                        history.append(frame)
                        if state["capture_active"]:
                            capture_buffer = state["capture_buffer"]
                            assert isinstance(capture_buffer, list)
                            capture_buffer.append(frame)
                            state["capture_frames"] = len(capture_buffer)
                        else:
                            del history[:-360]
                            state["capture_frames"] = 0
        except Exception as exc:
            with state_lock:
                state["connected"] = False
                state["error"] = str(exc)
            time.sleep(1.0)


def make_example_frames() -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    sample = 0
    sequence = list(range(0, 16)) + list(range(15, -1, -1))
    for switch_value in sequence:
        for perturb in (False, True) if switch_value in (5, 10, 15) else (False,):
            requested = min(1.0, (switch_value / 15.0) + (0.12 if perturb else 0.0))
            safe = min(requested, 0.60)
            frame = {
                "schema_version": "monogate-electronics.arty-trace-frame.v0",
                "kernel_id": "arty001_switch_guard_v0",
                "source": "arty-a7-example",
                "mode": "switch_guard",
                "sample_index": sample,
                "timestamp_ms": sample * 40,
                "switch_bits": format(switch_value, "04b"),
                "button_pressed": perturb,
                "outputs": {"requested_output": requested, "safe_output": safe, "led": safe},
                "guard": {
                    "guard_action": "clamp_to_safe_output" if requested > safe else "pass_through",
                    "safety_margin": max(0.0, 0.60 - requested),
                    "bottleneck": "led_duty_margin" if requested > safe else "none",
                },
            }
            rows.append(normalize_frame(frame, source_mode="example_trace"))
            sample += 1
    return rows


def snapshot_state() -> dict[str, object]:
    with state_lock:
        history = state["history"]
        assert isinstance(history, list)
        available_ports = state["available_ports"]
        assert isinstance(available_ports, list)
        return {
            "connected": state["connected"],
            "port": state["port"],
            "baud": state["baud"],
            "error": state["error"],
            "scanning": state["scanning"],
            "detected_port": state["detected_port"],
            "detected_label": state["detected_label"],
            "available_ports": available_ports,
            "latest": state["latest"],
            "frames": state["frames"],
            "started_at": state["started_at"],
            "updated_at": state["updated_at"],
            "history": history[-360:],
            "capture_active": state["capture_active"],
            "capture_frames": state["capture_frames"],
            "last_capture": state["last_capture"],
        }


class Handler(BaseHTTPRequestHandler):
    def log_message(self, format: str, *args: object) -> None:
        return

    def write_json(self, payload: object, status: int = 200) -> None:
        data = json.dumps(payload, indent=2).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def write_bytes(self, data: bytes, content_type: str, status: int = 200) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self) -> None:
        path = urlparse(self.path).path
        if path in ("/", "/visualizer"):
            self.write_bytes(VISUALIZER_PATH.read_bytes(), "text/html; charset=utf-8")
            return
        if path == "/history":
            self.write_json(snapshot_state())
            return
        if path == "/example":
            self.write_json({"history": make_example_frames(), "source_mode": "example_trace"})
            return
        if path == "/captures/latest":
            latest = latest_capture_path()
            if latest is None:
                self.write_json({"error": "no capture available"}, status=404)
                return
            frames = load_jsonl(latest, source_mode="replay_capture")
            self.write_json({"path": str(latest), "history": frames})
            return
        if path == "/capture/buffer":
            # The complete recorded run (every frame between Start and Stop), not the
            # 360-frame live tail. Survives Stop until the next Start, so "Save JSONL"
            # exports the full trace even after the recording ends.
            with state_lock:
                buf = list(state["capture_buffer"]) if isinstance(state["capture_buffer"], list) else []
                active = bool(state["capture_active"])
            self.write_json({"frames": buf, "count": len(buf), "capture_active": active})
            return
        if path == "/replay-skeleton":
            # The shared, course-agnostic instructor-replay template. The browser injects
            # frames + course config + meta into it to export a standalone verification HTML.
            try:
                self.write_bytes(SKELETON_PATH.read_bytes(), "text/html; charset=utf-8")
            except OSError:
                self.write_json({"error": "replay skeleton not found"}, status=404)
            return
        self.write_json({"error": "not found"}, status=404)

    def do_POST(self) -> None:
        path = urlparse(self.path).path
        if path == "/scan":
            with state_lock:
                state["available_ports"] = list_serial_ports()
                state["error"] = "Scan requested. Auto-detect loop will retry if the port is set to auto."
            self.write_json(snapshot_state())
            return
        if path == "/capture/start":
            with state_lock:
                state["capture_active"] = True
                state["capture_buffer"] = []
                state["capture_frames"] = 0
                state["last_capture"] = None
            self.write_json(snapshot_state())
            return
        if path == "/capture/stop":
            with state_lock:
                capture_buffer = list(state["capture_buffer"]) if isinstance(state["capture_buffer"], list) else []
                state["capture_active"] = False
                state["capture_frames"] = len(capture_buffer)
            if not capture_buffer:
                self.write_json({"error": "capture buffer is empty", **snapshot_state()}, status=400)
                return
            saved = write_capture(capture_buffer)
            with state_lock:
                state["last_capture"] = str(saved)
            self.write_json({"path": str(saved), "frames": len(capture_buffer), **snapshot_state()})
            return
        self.write_json({"error": "not found"}, status=404)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Serve the Arty A7 / FPGA serial dashboard.")
    parser.add_argument("--port", default=DEFAULT_SERIAL_PORT, help="Serial port, for example COM5 or auto")
    parser.add_argument("--baud", type=int, default=DEFAULT_BAUD, help="Serial baud rate")
    parser.add_argument("--http-port", type=int, default=DEFAULT_HTTP_PORT, help="Local HTTP dashboard port")
    parser.add_argument("--open-browser", action="store_true", help="Open the dashboard in the default browser")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    reader = threading.Thread(target=serial_reader, args=(args.port, args.baud), daemon=True)
    reader.start()

    server = ThreadingHTTPServer((HOST, args.http_port), Handler)
    url = f"http://{HOST}:{args.http_port}/"
    print(f"Arty A7 / FPGA dashboard: {url}")
    print(f"Reading {args.port} @ {args.baud}")
    if args.open_browser:
        webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("Stopping dashboard.")


if __name__ == "__main__":
    main()
