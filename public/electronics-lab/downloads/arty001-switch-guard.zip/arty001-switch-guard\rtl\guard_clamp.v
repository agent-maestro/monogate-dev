`timescale 1ns / 1ps

module guard_clamp (
    input wire [7:0] requested_output_q8,
    input wire [7:0] max_output_q8,
    output reg [7:0] safe_output_q8,
    output reg [7:0] safety_margin_q8,
    output reg guard_action
);
    always @(*) begin
        if (requested_output_q8 > max_output_q8) begin
            safe_output_q8 = max_output_q8;
            safety_margin_q8 = 8'd0;
            guard_action = 1'b1;
        end else begin
            safe_output_q8 = requested_output_q8;
            safety_margin_q8 = max_output_q8 - requested_output_q8;
            guard_action = 1'b0;
        end
    end
endmodule
